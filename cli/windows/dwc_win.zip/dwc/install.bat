@echo off
:: Copyright (c) 2026 ASUSTeK Computer Inc. All rights reserved.
::
:: install.bat - Architecture-aware launcher for the dwc installer.
::
:: Picks the win-x64 folder on 64-bit (AMD64) Windows and the win-x32 folder
:: otherwise, then runs that folder's own install.bat, which adds the folder
:: to PATH. Run this from the CLI.Release folder (the one that contains both
:: win-x32 and win-x64). Keep the whole folder in a permanent location.

setlocal

:: PROCESSOR_ARCHITEW6432 is set only when a 32-bit cmd.exe runs on 64-bit Windows,
:: where PROCESSOR_ARCHITECTURE would wrongly report x86.
set "ARCH=%PROCESSOR_ARCHITECTURE%"
if defined PROCESSOR_ARCHITEW6432 set "ARCH=%PROCESSOR_ARCHITEW6432%"

if /I "%ARCH%"=="AMD64" (
    set "TARGET=win-x64"
) else (
    :: x86, ARM64 (runs x86 binaries under emulation) and anything unknown
    set "TARGET=win-x32"
)

if not exist "%~dp0%TARGET%\install.bat" (
    echo [ERROR] "%~dp0%TARGET%\install.bat" was not found.
    echo         Make sure the whole CLI.Release folder was copied.
    pause
    exit /b 1
)

echo Detected architecture: %ARCH%  -^>  installing from %TARGET%
echo.
call "%~dp0%TARGET%\install.bat"
