# ASUS Display Control CLI (macOS)

Requires a Mac with Apple silicon (M1 or later).

## Installation

1. **Open Terminal** (Applications → Utilities → Terminal).

2. **Go to this folder.** For example, if it was unzipped into Downloads:

   ```
   cd ~/Downloads/macOS
   ```

   Tip: type `cd ` (with a trailing space), drag this folder from Finder into the
   Terminal window, then press Return.

3. **Run the installer** and enter your Mac password when asked:

   ```
   sh install.sh
   ```

4. **Verify** in the same Terminal window:

   ```
   dwc --help
   ```

dwc is copied into `/usr/local`, so it works in every Terminal window for all
users, and this folder can be deleted after installation.

### Installing without administrator rights

If you cannot enter an administrator password, install for your account only:

```
sh install.sh --user
```

Then open a new Terminal window before running `dwc`.

## Uninstallation

From this folder, run:

```
sh uninstall.sh
```

This removes dwc whichever way it was installed. If you have already deleted
this folder, download it again and run the command above.

> **Note:** Double-clicking `install.sh` in Finder only opens it in a text
> editor. Run it from Terminal as shown above.
