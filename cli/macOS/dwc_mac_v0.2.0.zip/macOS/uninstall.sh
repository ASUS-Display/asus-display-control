#!/bin/sh
# Copyright (c) 2026 ASUSTeK Computer Inc. All rights reserved.
#
# uninstall.sh - Removes every dwc install made by install.sh.
#
# Usage:
#   sh uninstall.sh
#
# Removes whatever is present, so it is safe to run more than once:
#   - the system-wide install (/usr/local/lib/dwc, /usr/local/bin/dwc);
#     asks for your password only if that install exists
#   - the current-user install (~/.local/share/dwc, ~/.local/bin/dwc) and its
#     PATH block in ~/.zshrc / ~/.bash_profile
#   - installs made by the previous version of install.sh (a copied
#     /usr/local/bin/dwc plus /usr/local/lib/libVCPLibrary.dylib, or a PATH
#     line pointing at the download folder)

set -eu

RC_BEGIN="# >>> dwc (ASUS display control CLI) >>>"
RC_END="# <<< dwc <<<"
LEGACY_RC_MARKER="# dwc display control CLI"

SYS_DIR="/usr/local/lib/dwc"
SYS_LINK="/usr/local/bin/dwc"
LEGACY_LIB="/usr/local/lib/libVCPLibrary.dylib"
USER_DIR="$HOME/.local/share/dwc"
USER_LINK="$HOME/.local/bin/dwc"

case "${1:-}" in
    "") ;;
    -h|--help) echo "Usage: sh $0"; exit 0 ;;
    *) echo "[ERROR] Unknown argument: $1"; echo "Usage: sh $0"; exit 2 ;;
esac

REMOVED="no"

# Run a command as root only when not root already; ask for the password once.
SUDO_READY="no"
as_root() {
    if [ "$(id -u)" -eq 0 ]; then
        "$@"
        return
    fi
    if [ "$SUDO_READY" = "no" ]; then
        echo "[INFO] Removing the system-wide install. Your password is required."
        sudo -v
        SUDO_READY="yes"
    fi
    sudo "$@"
}

# ---------------------------------------------------------------------------
# System-wide install
# ---------------------------------------------------------------------------
if [ -L "$SYS_LINK" ] && [ "$(readlink "$SYS_LINK")" = "$SYS_DIR/dwc" ]; then
    as_root rm -f "$SYS_LINK"
    echo "[OK] Removed $SYS_LINK"
    REMOVED="yes"
elif [ -f "$SYS_LINK" ] && [ ! -L "$SYS_LINK" ]; then
    # Previous install.sh copied the binary and the dylib directly.
    as_root rm -f "$SYS_LINK" "$LEGACY_LIB"
    echo "[OK] Removed $SYS_LINK and $LEGACY_LIB (older install)"
    REMOVED="yes"
fi

if [ -d "$SYS_DIR" ]; then
    as_root rm -rf "$SYS_DIR"
    echo "[OK] Removed $SYS_DIR"
    REMOVED="yes"
fi

# ---------------------------------------------------------------------------
# Current-user install
# ---------------------------------------------------------------------------
if [ -L "$USER_LINK" ] && [ "$(readlink "$USER_LINK")" = "$USER_DIR/dwc" ]; then
    rm -f "$USER_LINK"
    echo "[OK] Removed $USER_LINK"
    REMOVED="yes"
fi

if [ -d "$USER_DIR" ]; then
    rm -rf "$USER_DIR"
    echo "[OK] Removed $USER_DIR"
    REMOVED="yes"
fi

# Drop the PATH block written by install.sh, plus the single-line entry written
# by its previous version, together with the blank line that precedes either.
strip_rc() {
    rc="$1"
    [ -f "$rc" ] || return 0

    if grep -qF "$RC_BEGIN" "$rc" && ! grep -qF "$RC_END" "$rc"; then
        echo "[WARN] $rc has the dwc start marker but no end marker; edit it by hand."
        return 0
    fi

    tmp="$(mktemp)"
    awk -v b="$RC_BEGIN" -v e="$RC_END" -v legacy="$LEGACY_RC_MARKER" '
        function flush() { if (blank) { print ""; blank = 0 } }
        skip             { if ($0 == e) skip = 0; next }
        $0 == b          { blank = 0; skip = 1; next }
        $0 == legacy     { blank = 0; dropnext = 1; next }
        dropnext         { dropnext = 0; if ($0 ~ /^export PATH=/) next }
        $0 == ""         { flush(); blank = 1; next }
                         { flush(); print }
        END              { flush() }
    ' "$rc" > "$tmp"

    if cmp -s "$rc" "$tmp"; then
        rm -f "$tmp"
    else
        # Write through the original file so a symlinked rc file and its
        # permissions are kept.
        cat "$tmp" > "$rc"
        rm -f "$tmp"
        echo "[OK] Removed the dwc PATH entry from $rc"
        REMOVED="yes"
    fi
}

strip_rc "$HOME/.zshrc"
strip_rc "$HOME/.bash_profile"

echo ""
echo "============================================================"
if [ "$REMOVED" = "yes" ]; then
    echo "  SUCCESS: dwc has been uninstalled."
    echo "  Terminal windows that are already open may still find dwc"
    echo "  until they are closed."
else
    echo "  Nothing to remove: dwc is not installed."
fi
echo "============================================================"
