#!/bin/sh
# Copyright (c) 2026 ASUSTeK Computer Inc. All rights reserved.
#
# install.sh - Installs the dwc CLI so it can be run from any Terminal window.
#
# Usage:
#   sh install.sh            # system-wide install (default; asks for your password)
#   sh install.sh --user     # current-user install, no administrator rights needed
#   sh install.sh --help
#
# System-wide: copies dwc and libVCPLibrary.dylib together into
# /usr/local/lib/dwc and links /usr/local/bin/dwc to it. /usr/local/bin is on
# the default macOS PATH, so dwc works right away in every Terminal window,
# including the one that ran this script.
#
# Current user: copies the files into ~/.local/share/dwc, links
# ~/.local/bin/dwc to it, and adds ~/.local/bin to PATH in ~/.zshrc (and in
# ~/.bash_profile if that file exists). New Terminal windows pick it up.
#
# The dwc binary itself is never modified: it finds libVCPLibrary.dylib through
# its @executable_path rpath, which macOS resolves through the symlink to the
# real install directory. The downloaded folder can be deleted afterwards.
# Run "sh uninstall.sh" to remove either kind of install.

set -eu

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SRC_BIN="$SCRIPT_DIR/dwc"
SRC_LIB="$SCRIPT_DIR/libVCPLibrary.dylib"

RC_BEGIN="# >>> dwc (ASUS display control CLI) >>>"
RC_END="# <<< dwc <<<"

usage() {
    echo "Usage: sh $0 [--system | --user]"
    echo "  --system  install for all users into /usr/local (default, needs your password)"
    echo "  --user    install for the current user only into ~/.local"
}

MODE="system"
for arg in "$@"; do
    case "$arg" in
        --system)  MODE="system" ;;
        --user)    MODE="user" ;;
        -h|--help) usage; exit 0 ;;
        *)
            echo "[ERROR] Unknown argument: $arg"
            usage
            exit 2
            ;;
    esac
done

[ -f "$SRC_BIN" ] || { echo "[ERROR] dwc not found in '$SCRIPT_DIR'."; exit 1; }
[ -f "$SRC_LIB" ] || { echo "[ERROR] libVCPLibrary.dylib not found in '$SCRIPT_DIR'."; exit 1; }

if [ "$MODE" = "system" ]; then
    INSTALL_DIR="/usr/local/lib/dwc"
    LINK_DIR="/usr/local/bin"
    SUDO=""
    if [ "$(id -u)" -ne 0 ]; then
        SUDO="sudo"
        echo "[INFO] Installing dwc for all users. Your password is required."
        if ! sudo -v; then
            echo "[ERROR] Administrator rights were not granted."
            echo "        Run 'sh $0 --user' to install for the current user only."
            exit 1
        fi
    fi
else
    INSTALL_DIR="$HOME/.local/share/dwc"
    LINK_DIR="$HOME/.local/bin"
    SUDO=""
    echo "[INFO] Installing dwc for the current user."
fi
LINK="$LINK_DIR/dwc"

# An install made by the previous version of this script left a real file
# (not a symlink) at /usr/local/bin/dwc and the dylib loose in /usr/local/lib.
if [ "$MODE" = "system" ] && [ -f "$LINK" ] && [ ! -L "$LINK" ]; then
    echo "[INFO] Replacing an older dwc install at $LINK."
    $SUDO rm -f "$LINK" "/usr/local/lib/libVCPLibrary.dylib"
fi

$SUDO mkdir -p "$INSTALL_DIR" "$LINK_DIR"

# Remove before copying: overwriting a signed Mach-O in place can make the
# kernel kill the new binary on launch because of its cached code signature.
$SUDO rm -f "$INSTALL_DIR/dwc" "$INSTALL_DIR/libVCPLibrary.dylib"
$SUDO cp "$SRC_BIN" "$INSTALL_DIR/dwc"
$SUDO cp "$SRC_LIB" "$INSTALL_DIR/libVCPLibrary.dylib"
$SUDO chmod 755 "$INSTALL_DIR/dwc" "$INSTALL_DIR/libVCPLibrary.dylib"

# Files from a browser download carry the quarantine flag, which makes
# Gatekeeper refuse to run dwc or load its dylib from the command line.
$SUDO xattr -d com.apple.quarantine "$INSTALL_DIR/dwc" 2>/dev/null || true
$SUDO xattr -d com.apple.quarantine "$INSTALL_DIR/libVCPLibrary.dylib" 2>/dev/null || true

$SUDO ln -sfn "$INSTALL_DIR/dwc" "$LINK"

# Run through the symlink to prove that the dylib is found from there.
if ! VERSION="$("$LINK" --version 2>&1)"; then
    echo "[ERROR] dwc was copied but does not start:"
    echo "$VERSION"
    exit 1
fi
echo "[OK] Installed dwc $VERSION to $INSTALL_DIR (command: $LINK)."

# ---------------------------------------------------------------------------
# Current-user install: make sure ~/.local/bin is on PATH.
# ---------------------------------------------------------------------------
add_path_block() {
    rc="$1"
    if [ -f "$rc" ] && grep -qF "$RC_BEGIN" "$rc"; then
        echo "[OK] $rc already adds ~/.local/bin to PATH."
        return 0
    fi
    # $HOME and $PATH are written literally; the shell expands them at startup.
    printf '\n%s\nexport PATH="$HOME/.local/bin:$PATH"\n%s\n' "$RC_BEGIN" "$RC_END" >> "$rc"
    echo "[OK] Added ~/.local/bin to PATH in $rc."
}

ON_PATH="yes"
if [ "$MODE" = "user" ]; then
    case ":$PATH:" in
        *":$LINK_DIR:"*) ;;
        *)
            ON_PATH="no"
            # zsh is the default macOS shell; only touch bash's file if it is in use,
            # since creating ~/.bash_profile would stop bash from reading ~/.profile.
            add_path_block "$HOME/.zshrc"
            [ -f "$HOME/.bash_profile" ] && add_path_block "$HOME/.bash_profile"
            ;;
    esac
fi

# Warn when some other dwc comes earlier in PATH and would shadow this one.
if [ "$ON_PATH" = "yes" ]; then
    FOUND="$(command -v dwc 2>/dev/null || true)"
    if [ -n "$FOUND" ] && [ "$FOUND" != "$LINK" ]; then
        echo "[WARN] '$FOUND' comes before '$LINK' in your PATH,"
        echo "       so typing 'dwc' runs that one instead."
    fi
fi

echo ""
echo "============================================================"
echo "  SUCCESS: dwc is installed."
echo ""
if [ "$ON_PATH" = "yes" ]; then
    echo "  You can use it right away in any Terminal window:"
else
    echo "  Open a new Terminal window, or run this in the current one:"
    echo "    export PATH=\"\$HOME/.local/bin:\$PATH\""
    echo "  and then:"
fi
echo "    dwc --help"
echo ""
echo "  This folder is no longer needed and can be deleted."
echo "============================================================"
